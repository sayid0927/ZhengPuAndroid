package com.zhengpu.zhengpuandroid.iflytekaction;

import android.content.Context;
import android.content.Intent;

import com.zhengpu.zhengpuandroid.ui.activity.MainActivity;


public class CallView {

    private Context context;

    public CallView(Context context) {
        this.context = context;
    }

    public void start() {
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_CALL_BUTTON);
        context.startActivity(intent);
    }
}
