package com.zhengpu.zhengpuandroid.bean.iflytekbean;

import java.util.List;

/**
 * Created by Howe on 2016/10/23.
 */

public class DataBean {


    private List<ResultBean> result;
    private ResultBean mResultBean;

    public List<ResultBean> getResult() {
        return result;
    }

    public void setResult(List<ResultBean> result) {
        this.result = result;
    }

}