package com.zhengpu.zhengpuandroid.iflytekaction;

import android.content.Context;
import android.content.Intent;

import com.zhengpu.zhengpuandroid.ui.activity.MainActivity;


public class MessageView {
	private Context context;
	
	public MessageView(Context context){
		this.context=context;
	}
	
	public void start(){
		Intent intent=new Intent();
		intent.setClassName("com.android.mms","com.android.mms.ui.ConversationList");
		context.startActivity(intent);
	}
}
