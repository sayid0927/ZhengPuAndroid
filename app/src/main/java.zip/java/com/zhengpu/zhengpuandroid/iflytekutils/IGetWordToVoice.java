package com.zhengpu.zhengpuandroid.iflytekutils;

/**
 * sayid ....
 * Created by wengmf on 2017/11/22.
 */

public interface IGetWordToVoice {

    void  SpeechEnd();

    void SpeechError();


}
