package com.zhengpu.zhengpuandroid.bean.request;

/**
 * Created by Administrator on 2017/11/3 0003.
 */

public class Meinvha_Title_request {

    private int id;
    private int start_Page;
    private int end_Page;

    public int getStart_Page() {
        return start_Page;
    }

    public void setStart_Page(int start_Page) {
        this.start_Page = start_Page;
    }

    public int getEnd_Page() {
        return end_Page;
    }

    public void setEnd_Page(int end_Page) {
        this.end_Page = end_Page;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
