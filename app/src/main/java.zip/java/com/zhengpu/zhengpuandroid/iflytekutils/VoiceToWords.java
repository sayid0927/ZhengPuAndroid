package com.zhengpu.zhengpuandroid.iflytekutils;

import android.content.Context;
import android.os.Bundle;
import android.os.Environment;
import android.text.TextUtils;
import android.util.Log;
import android.widget.EditText;
import android.widget.Toast;

import com.iflytek.cloud.ErrorCode;
import com.iflytek.cloud.InitListener;
import com.iflytek.cloud.SpeechConstant;
import com.iflytek.cloud.SpeechError;
import com.iflytek.cloud.SpeechUnderstander;
import com.iflytek.cloud.SpeechUnderstanderListener;
import com.iflytek.cloud.UnderstanderResult;
import com.orhanobut.logger.Logger;
import com.zhengpu.zhengpuandroid.base.AppController;
import com.zhengpu.zhengpuandroid.bean.iflytekbean.AnswerBean;
import com.zhengpu.zhengpuandroid.bean.iflytekbean.DataBean;
import com.zhengpu.zhengpuandroid.bean.iflytekbean.DatetimeBean;
import com.zhengpu.zhengpuandroid.bean.iflytekbean.MainBean;
import com.zhengpu.zhengpuandroid.bean.iflytekbean.ResultBean;
import com.zhengpu.zhengpuandroid.bean.iflytekbean.SlotsBean;
import com.zhengpu.zhengpuandroid.iflytekaction.CallAction;
import com.zhengpu.zhengpuandroid.iflytekaction.CallView;
import com.zhengpu.zhengpuandroid.iflytekaction.MessageView;
import com.zhengpu.zhengpuandroid.iflytekaction.OpenAppAction;
import com.zhengpu.zhengpuandroid.iflytekaction.OpenQA;
import com.zhengpu.zhengpuandroid.iflytekaction.ScheduleCreate;
import com.zhengpu.zhengpuandroid.iflytekaction.ScheduleView;
import com.zhengpu.zhengpuandroid.iflytekaction.SearchAction;
import com.zhengpu.zhengpuandroid.iflytekaction.SearchApp;
import com.zhengpu.zhengpuandroid.iflytekaction.SearchWeather;
import com.zhengpu.zhengpuandroid.iflytekaction.SendMessage;
import com.zhengpu.zhengpuandroid.ui.activity.MainActivity;

import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Random;

/**
 * sayid ....
 * Created by wengmf on 2017/11/22.
 */

public class VoiceToWords {

    private static String TAG = "VoiceToWords类";
    // 语音听写对象
//    private SpeechRecognizer mIat;
    private SpeechUnderstander mIat;
    // 用HashMap存储听写结果
    private HashMap<String, String> mIatResults = new LinkedHashMap<String, String>();
    //提示toast
    //private Toast mToast;
    //context
    private Context context;
    // 函数调用返回值,表示返回结果，失败或成功
    int ret = 0;
    //设置回调接口
    private IGetVoiceToWord mIGetVoiceToWord;

    private EditText txtOfUser;

    private MainBean mMainBean;



    /**
     * 构造方法
     */
    public VoiceToWords(Context context, IGetVoiceToWord mIGetVoiceToWord) {
        this.context = context;
        this.mIGetVoiceToWord = mIGetVoiceToWord;
        this.txtOfUser = txtOfUser;
        //mToast = Toast.makeText(context, "", Toast.LENGTH_SHORT);
        // 初始化识别无UI识别对象
        // 使用SpeechRecognizer对象，可根据回调消息自定义界面；
        // SpeechRecognizer.createRecognizer(context, mInitListener);
        mIat = SpeechUnderstander.createUnderstander(context,mInitListener);

        //设置参数
        setParams();
    }

    /**
     * 初始化监听器
     */
    private InitListener mInitListener = new InitListener() {

        @Override
        public void onInit(int code) {
            if (code != ErrorCode.SUCCESS) {
               Logger.t(TAG).e("初始化失败，错误码：" + code);
            }
        }
    };

    /**
     * 展示提示框
     */
    private void showTip(final String str) {
        Toast.makeText(context, str, Toast.LENGTH_SHORT).show();
    }

    /**
     * 开始语音听写
     */
    public void startRecognizer() {

        //清空听写结果
        mIatResults.clear();
//        ret = mIat.startListening(mRecognizerListener);
        ret = mIat.startUnderstanding(mSpeechUnderstanderListener);

        if (ret != ErrorCode.SUCCESS)
            Logger.e("听写失败,错误码：" + ret);

    }

    /**
     * 听写监听器。
     */
//    private RecognizerListener mRecognizerListener = new RecognizerListener() {
//
//        @Override
//        public void onBeginOfSpeech() {
//            // 此回调表示：sdk内部录音机已经准备好了，用户可以开始语音输入
//            Logger.t(TAG).e("开始说话");
//        }
//
//        @Override
//        public void onError(SpeechError error) {
//            // Tips：
//            // 错误码：10118(您没有说话)，可能是录音机权限被禁，需要提示用户打开应用的录音权限。
//            // 如果使用本地功能（语记）需要提示用户开启语记的录音权限。
//            // showTip(error.getPlainDescription(true));
//            if("您好像没有说话哦.(错误码:10118)".equals(error.getPlainDescription(true))){
//                String lowVoiceTip="";
//                int i=new Random().nextInt(3);
//                switch (i){
//                    case 0:
//                        lowVoiceTip="声音太小了，听不清呢";
//                        break;
//                    case 1:
//                        lowVoiceTip="有在说话吗，没听到啊";
//                        break;
//                    case 2:
//                        lowVoiceTip="您好像没有说话呢";
//                        break;
//                }
//                mIGetVoiceToWord.showLowVoice(lowVoiceTip);
//            }
//        }
//
//        @Override
//        public void onEndOfSpeech() {
//            // 此回调表示：检测到了语音的尾端点，已经进入识别过程，不再接受语音输入
//            Logger.t(TAG).e("讯飞结束说话");
//            mIGetVoiceToWord.SpeechOver();
//        }
//
//        //        结果回调处
//        @Override
//        public void onResult(RecognizerResult results, boolean isLast) {
//            String text = printResult(results);
//            if(isLast&&!"".equals(text)){
//                mIGetVoiceToWord.appendResult(text);
//                mIGetVoiceToWord.getResult(text);
//            }
//        }
//
//        @Override
//        public void onVolumeChanged(int volume, byte[] data) {
//            //showTip("当前正在说话，音量大小：" + volume);
//            //Log.d(TAG, "返回音频数据：" + data.length);
//            //L.i("返回音频数据"+ data.length);
//        }
//
//        //打印结果
//        private String printResult(RecognizerResult results) {
//            String text = VoiceParser.parseIatResult(results.getResultString());
//
//            String sn = null;
//            // 读取json结果中的sn字段
//            try {
//                JSONObject resultJson = new JSONObject(results.getResultString());
//                sn = resultJson.optString("sn");
//            } catch (JSONException e) {
//                e.printStackTrace();
//            }
//
//            mIatResults.put(sn, text);
//
//            StringBuffer resultBuffer = new StringBuffer();
//            for (String key : mIatResults.keySet()) {
//                resultBuffer.append(mIatResults.get(key));
//            }
//            return resultBuffer.toString();
//        }
//
//
//        @Override
//        public void onEvent(int eventType, int arg1, int arg2, Bundle obj) {
//            // 以下代码用于获取与云端的会话id，当业务出错时将会话id提供给技术支持人员，可用于查询会话日志，定位出错原因
//            // 若使用本地能力，会话id为null
//            //	if (SpeechEvent.EVENT_SESSION_ID == eventType) {
//            //		String sid = obj.getString(SpeechEvent.KEY_EVENT_SESSION_ID);
//            //		Log.d(TAG, "session id =" + sid);
//            //	}
//        }
//    };

    /**
     * 为听写对象设置参数
     */
    private void setParams() {
        //默认不设置的语音参数
        //SpeechConstant.NET_TIMEOUT:网络连接超时时间 默认20秒
        //SpeechConstant.KEY_SPEECH_TIMEOUT:语音输入超时时间  默认60秒
        //mIat.setParameter(SpeechConstant.SAMPLE_RATE, "16000") 默认的识别采样率支持16000Hz和8000Hz
        // 清空参数
        mIat.setParameter(SpeechConstant.PARAMS, null);
        //设置语音输入超时时间
        mIat.setParameter(SpeechConstant.KEY_SPEECH_TIMEOUT,"100000");
        mIat.setParameter(SpeechConstant.SAMPLE_RATE, "16000");
        // 设置听写引擎
        mIat.setParameter(SpeechConstant.ENGINE_TYPE, SpeechConstant.TYPE_CLOUD);
        // 设置返回结果格式
        mIat.setParameter(SpeechConstant.RESULT_TYPE, "json");
        //获得当前系统的语言
        String language = context.getResources().getConfiguration().locale.getCountry();
        // 设置语言
        if (language.equals("US")) {
            // 设置语言
            mIat.setParameter(SpeechConstant.LANGUAGE, "en_us");
        } else {
            // 设置语言
            mIat.setParameter(SpeechConstant.LANGUAGE, "zh_cn");
            // 设置语言区域
            mIat.setParameter(SpeechConstant.ACCENT, "mandarin");
        }
        //应用领域
        //mIat.setParameter(SpeechConstant.DOMAIN, "iat");

        // 传入音频源。
        //录音机的录音方式，默认为MIC(MediaRecorder.AudioSource.MIC)
        // 设置音频来源为外部文件
        //mIat.setParameter(SpeechConstant.AUDIO_SOURCE, "-1");
        // 也可以像以下这样直接设置音频文件路径识别（要求设置文件在sdcard上的全路径）：
        // mIat.setParameter(SpeechConstant.AUDIO_SOURCE, "-2");
        // mIat.setParameter(SpeechConstant.ASR_SOURCE_PATH, "sdcard/XXX/XXX.pcm");

        mIat.setParameter(SpeechConstant.VAD_ENABLE,"1");
        // 设置语音前端点:静音超时时间，即用户多长时间不说话则当做超时处理
        mIat.setParameter(SpeechConstant.VAD_BOS, "10000");

        // 设置语音后端点:后端点静音检测时间，即用户停止说话多长时间内即认为不再输入， 自动停止录音
        mIat.setParameter(SpeechConstant.VAD_EOS, "2000");
        // 设置标点符号,设置为"0"返回结果无标点,设置为"1"返回结果有标点
        mIat.setParameter(SpeechConstant.ASR_PTT, "0");
        // 设置音频保存路径，保存音频格式支持pcm、wav，设置路径为sd卡请注意WRITE_EXTERNAL_STORAGE权限
        // 注：AUDIO_FORMAT参数语记需要更新版本才能生效
        mIat.setParameter(SpeechConstant.AUDIO_FORMAT, "wav");
        mIat.setParameter(SpeechConstant.ASR_AUDIO_PATH, Environment.getExternalStorageDirectory() + "/abcd/iat.wav");
        // 设置返回结果格式
        mIat.setParameter(SpeechConstant.RESULT_TYPE, "json");
    }

    public boolean isIatListening() {
        return mIat.isUnderstanding();
    }


    //停止录音，开始解析
    public void mTtsStop() {
        // 退出时释放连接
        if (mIat != null&&mIat.isUnderstanding()) {
            mIat.stopUnderstanding();
        }
    }

    public void mIatDestroy() {

        // 退出时释放连接
        if(mIat != null) {
            if(mIat.isUnderstanding()){
                mIat.cancel();
            }
            mIat.destroy();
        }
    }





    /**
     * 语义理解回调。
     */
    private SpeechUnderstanderListener mSpeechUnderstanderListener = new SpeechUnderstanderListener() {

        @Override
        public void onResult(final UnderstanderResult result) {
            if (null != result) {
                Logger.e(result.getResultString());

                // 显示
                String text = result.getResultString();
                Logger.e(text);
                mMainBean = JsonParser.parseIatResult(text);
                if (!TextUtils.isEmpty(text)) {
                    if (mMainBean.getRc() == 0) {
                        AppController.SRResult = mMainBean.getText();
                        judgeService();
                    } else {
                        mIGetVoiceToWord.showLowVoice("我听不懂您说什么");
                    }
                }
            } else {
                showTip("识别结果不正确。");
            }
        }

        @Override
        public void onVolumeChanged(int volume, byte[] data) {
            //showTip("当前正在说话，音量大小：" + volume);
            //Log.d(TAG, "返回音频数据：" + data.length);
            //Log.d("返回音频数据"+ data.length);
        }

        @Override
        public void onEndOfSpeech() {
            // 此回调表示：检测到了语音的尾端点，已经进入识别过程，不再接受语音输入
            //showTip("结束说话");

        }

        @Override
        public void onBeginOfSpeech() {
            // 此回调表示：检测到了语音的尾端点，已经进入识别过程，不再接受语音输入
            Logger.t(TAG).e("讯飞结束说话");
            mIGetVoiceToWord.SpeechOver();
        }

        @Override
        public void onError(SpeechError error) {
            // Tips：
            // 错误码：10118(您没有说话)，可能是录音机权限被禁，需要提示用户打开应用的录音权限。
            // 如果使用本地功能（语记）需要提示用户开启语记的录音权限。
            // showTip(error.getPlainDescription(true));
            if("您好像没有说话哦.(错误码:10118)".equals(error.getPlainDescription(true))){
                String lowVoiceTip="";
                int i=new Random().nextInt(3);
                switch (i){
                    case 0:
                        lowVoiceTip="声音太小了，听不清呢";
                        break;
                    case 1:
                        lowVoiceTip="有在说话吗，没听到啊";
                        break;
                    case 2:
                        lowVoiceTip="您好像没有说话呢";
                        break;
                }
                mIGetVoiceToWord.showLowVoice(lowVoiceTip);
            }
        }

        @Override
        public void onEvent(int eventType, int arg1, int arg2, Bundle obj) {
            // 以下代码用于获取与云端的会话id，当业务出错时将会话id提供给技术支持人员，可用于查询会话日志，定位出错原因
            // 若使用本地能力，会话id为null
            //	if (SpeechEvent.EVENT_SESSION_ID == eventType) {
            //		String sid = obj.getString(SpeechEvent.KEY_EVENT_SESSION_ID);
            //		Log.d(TAG, "session id =" + sid);
            //	}

        }
    };



    //语义场景判断
    private void judgeService() {

        AppController.SRResult = null;
        String service = mMainBean.getService();
        String operation = mMainBean.getOperation();

        AnswerBean answerBean = new AnswerBean();
        SlotsBean slotsBean = new SlotsBean();
        DatetimeBean datetimeBean = new DatetimeBean();
        ResultBean resultBean = new ResultBean();
        DataBean dataBean = new DataBean();

        String date = "该天";

        if (mMainBean.getAnswer() != null) {
            answerBean = mMainBean.getAnswer();
        }


        if (mMainBean.getSemantic() != null) {
            if (mMainBean.getSemantic().getSlots() != null) {
                slotsBean = mMainBean.getSemantic().getSlots();
                if (mMainBean.getSemantic().getSlots().getDatetime() != null) {
                    datetimeBean = mMainBean.getSemantic().getSlots().getDatetime();
                }
            }
        }


        if (mMainBean.getData() != null) {
            if (mMainBean.getData().getResult() != null) {
                if (mMainBean.getSemantic().getSlots().getDatetime() != null) {
                    Calendar calendar = Calendar.getInstance();
                    int today = calendar.get(Calendar.DAY_OF_MONTH);
                    dataBean = mMainBean.getData();
                    String day = datetimeBean.getDate().substring(datetimeBean.getDate().length() - 2, datetimeBean.getDate().length());
                    if (day.equals("AY")) {
                        day = today + "";
                    }
                    int getday = Integer.parseInt(day);
                    int sub = getday - today;
                    resultBean = dataBean.getResult().get(sub);

                    if (sub == 0) {
                        date = "今天";
                    } else if (sub == 1) {
                        date = "明天";
                    } else if (sub == 2) {
                        date = "后天";
                    } else if (sub == 3) {
                        date = "大后天";
                    } else if (sub == 4) {
                        date = "四天后";
                    } else if (sub == 5) {
                        date = "五天后";
                    } else if (sub == 6) {
                        date = "六天后";
                    }
                }
            }
        }

        if (AppController.service_flag == false) {//如果不在一项服务中才进行服务的判断


            switch (service) {

                case "telephone":
                    switch (operation) {
                        case "CALL": {    //1打电话
                            //必要条件【电话号码code】
                            //可选条件【人名name】【类型category】【号码归属地location】【运营商operator】【号段head_num】【尾号tail_num】
                            //可由多个可选条件确定必要条件
                            CallAction callAction = new CallAction(slotsBean.getName(), slotsBean.getCode(), context);//目前可根据名字或电话号码拨打电话
                            callAction.start();
                            break;
                        }
                        case "VIEW": {    //2查看电话拨打记录
                            //必要条件无
                            //可选条件【未接电话】【已拨电话】【已接电话】
                            CallView callview = new CallView(context);
                            callview.start();
                            break;
                        }
                        default:
                            break;
                    }

                    break;
                case "message": {//2 短信相关服务

                    switch (operation) {

                        case "SEND": {//1发送短信
                            SendMessage sendMessage = new SendMessage(slotsBean.getName(), slotsBean.getCode(), slotsBean.getContent(), context);
                            sendMessage.start();
                            break;
                        }

                        case "VIEW": {//2查看发送短信页面

                            MessageView messageView = new MessageView(context);
                            messageView.start();
                            break;
                        }

                        default:
                            break;
                    }

                    break;
                }
                case "app": {//3 应用相关服务

                    switch (operation) {

                        case "LAUNCH": {//1打开应用
                            OpenAppAction openApp = new OpenAppAction(slotsBean.getName(), context);
                            openApp.start();
                            break;
                        }

                        case "QUERY": {//2应用中心搜索应用
                            SearchApp searchApp = new SearchApp(slotsBean.getName(), context);
                            searchApp.start();
                            break;
                        }

                        default:
                            break;

                    }
                    break;
                }

                case "websearch": {//5 搜索相关服务

                    switch (operation) {

                        case "QUERY": {//1搜索

                            SearchAction searchAction = new SearchAction(slotsBean.getKeywords(), context);
                            searchAction.Search();
                            break;
                        }

                        default:
                            break;

                    }

                    break;
                }

                case "faq": {//6 社区问答相关服务

                    switch (operation) {
                        case "ANSWER": {//1社区问答
                            OpenQA openQA = new OpenQA(answerBean.getText());
                            openQA.start();
                            break;
                        }
                        default:
                            break;
                    }

                    break;

                }

                case "chat": {//7 聊天相关服务

                    switch (operation) {

                        case "ANSWER": {//1聊天模式

                            OpenQA openQA = new OpenQA(answerBean.getText());
                            openQA.start();

                            break;
                        }

                        default:
                            break;
                    }

                    break;
                }

                case "openQA": {//8 智能问答相关服务

                    switch (operation) {

                        case "ANSWER": {//1智能问答

                            OpenQA openQA = new OpenQA(answerBean.getText());
                            openQA.start();

                            break;
                        }

                        default:
                            break;
                    }

                    break;
                }

                case "baike": {//9 百科知识相关服务

                    switch (operation) {

                        case "ANSWER": {//1百科

                            OpenQA openQA = new OpenQA(answerBean.getText());
                            openQA.start();

                            break;
                        }

                        default:
                            break;
                    }

                    break;
                }

                case "schedule": {//10 日程相关服务

                    switch (operation) {

                        case "CREATE": {//1创建日程/闹钟(直接跳转相应设置界面)

                            ScheduleCreate scheduleCreate = new ScheduleCreate(slotsBean.getName(), datetimeBean.getTime(), datetimeBean.getDate(), slotsBean.getContent(), context);
                            scheduleCreate.start();

                            break;
                        }

                        case "VIEW": {//1查看闹钟/日历(未实现)

                            ScheduleView scheduleView = new ScheduleView(slotsBean.getName(), datetimeBean.getTime(), datetimeBean.getDate(), slotsBean.getContent(), context);
                            scheduleView.start();
                            break;
                        }


                        default:
                            break;
                    }

                    break;
                }

                case "weather": {//11 天气相关服务

                    switch (operation) {

                        case "QUERY": {//1查询天气

                            SearchWeather searchWeather = new SearchWeather(date, resultBean.getCity(), resultBean.getSourceName(), resultBean.getDate(), resultBean.getWeather(), resultBean.getTempRange(), resultBean.getAirQuality(), resultBean.getWind(), resultBean.getHumidity(), resultBean.getWindLevel() + "");
                            searchWeather.start();

                            break;
                        }

                        default:
                            break;

                    }

                    break;
                }
                default:
                    WordsToVoice.startSynthesizer("我听不懂您说什么，亲爱的，下次可能我就明白了");
                    break;
            }
        }

    }




}
