package com.zhengpu.zhengpuandroid.ui.activity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;

import com.iflytek.cloud.ErrorCode;
import com.iflytek.cloud.InitListener;
import com.iflytek.cloud.SpeechError;
import com.iflytek.cloud.SpeechSynthesizer;
import com.iflytek.cloud.SpeechUnderstander;
import com.iflytek.cloud.SynthesizerListener;
import com.iflytek.sunflower.FlowerCollector;
import com.zhengpu.zhengpuandroid.R;
import com.zhengpu.zhengpuandroid.base.BaseActivity;
import com.zhengpu.zhengpuandroid.bean.Apk_Update;
import com.zhengpu.zhengpuandroid.component.AppComponent;
import com.zhengpu.zhengpuandroid.component.DaggerMainComponent;
import com.zhengpu.zhengpuandroid.presenter.contract.MainContract;
import com.zhengpu.zhengpuandroid.presenter.impl.MainActivityPresenter;
import com.zhengpu.zhengpuandroid.service.DownLoadService;
import com.zhengpu.zhengpuandroid.service.SpeechRecognizerService;
import com.zhengpu.zhengpuandroid.utils.DeviceUtils;
import com.zhengpu.zhengpuandroid.iflytekutils.IflytekWakeUp;
import com.zhengpu.zhengpuandroid.utils.ToastUtils;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.OnClick;

public class MainActivity extends BaseActivity implements MainContract.View {

    private String TAG = MainActivity.class.getSimpleName();
    public static MainActivity install;
    @BindView(R.id.butn)
    Button butn;
    @Inject
    MainActivityPresenter mPresenter;

    public static int FileSize;
    public static String Apk_Name;
    private IflytekWakeUp iflytekWakeUp;


    @Override
    protected void setupActivityComponent(AppComponent appComponent) {
        DaggerMainComponent.builder().appComponent(appComponent).build().inject(this);
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_main;
    }

    @Override
    public void attachView() {
        mPresenter.attachView(this);
    }

    @Override
    public void detachView() {
        mPresenter.detachView();
    }

    @Override
    public void initView() {

        install = this;
        mPresenter.Apk_Update();
        startService(new Intent(MainActivity.this, SpeechRecognizerService.class));

    }

    @Override
    public void Apk_Update_Success(Apk_Update.DataBean dataBean) {
        FileSize = dataBean.getFileSize();
        Apk_Name = dataBean.getApk_Name();
        String version_info = dataBean.getUpdate_Info();         //更新提示信息
        int mVersion_code = DeviceUtils.getVersionCode(MainActivity.this);// 当前的版本号
        int nVersion_code = dataBean.getVersionCode();            // 服务器上的版本号

        if (mVersion_code < nVersion_code) {
            // 显示提示对话
            showNoticeDialog(version_info);
        } else {

        }
    }

    @Override
    public void showError(String message) {

    }

    /**
     * 显示更新对话框
     *
     * @param version_info
     */
    private void showNoticeDialog(String version_info) {
        // 构造对话框
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("更新提示");
        builder.setMessage(version_info);
        // 更新
        builder.setPositiveButton("立即更新", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                startService(new Intent(MainActivity.this, DownLoadService.class));

            }
        });
        // 稍后更新
        builder.setNegativeButton("以后更新", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();

            }
        });
        Dialog noticeDialog = builder.create();
        noticeDialog.show();

    }


}


