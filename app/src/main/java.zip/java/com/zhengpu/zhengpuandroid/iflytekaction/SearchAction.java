package com.zhengpu.zhengpuandroid.iflytekaction;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;

import com.zhengpu.zhengpuandroid.iflytekutils.WordsToVoice;
import com.zhengpu.zhengpuandroid.ui.activity.MainActivity;


public class SearchAction {
	private Context context;
	String mKeyword;
	//String searchEngine;

	public SearchAction(String name, Context context)
	{
		mKeyword = name;
		this.context=context;
	}

	public void Search(){
		startWebSearch();
	}

	private void startWebSearch()
	{
		WordsToVoice.startSynthesizer("正在搜索："+mKeyword+"...");
		Intent intent = new Intent();
		intent.setAction(Intent.ACTION_VIEW);
		intent.setData(Uri.parse("http://m.baidu.com/s?word="+mKeyword));
		intent.setClassName("com.android.browser","com.android.browser.BrowserActivity");//设置为系统自带浏览器启动
		context.startActivity(intent);
	}
}
