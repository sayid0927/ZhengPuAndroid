package com.zhengpu.zhengpuandroid.iflytekaction;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;

import com.zhengpu.zhengpuandroid.iflytekutils.WordsToVoice;
import com.zhengpu.zhengpuandroid.ui.activity.MainActivity;


public class SearchApp {
	private String mName;
	private Context context;

	public SearchApp(String name, Context context){
		mName=name;
		this.context=context;
	}

	public void start(){
		WordsToVoice.startSynthesizer("正在搜索...");
		Intent intent = new Intent(Intent.ACTION_VIEW);
		intent.setData(Uri.parse("market://search?q="+mName));
		context.startActivity(intent);
	}
}
