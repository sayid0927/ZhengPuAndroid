package com.zhengpu.zhengpuandroid.base;

/**
 * sayid ....
 * Created by wengmf on 2017/11/22.
 */

public class AppController {


    public static boolean service_flag = false;//表示是否在一项服务中
    public static String SRResult = "";    //识别结果




}
