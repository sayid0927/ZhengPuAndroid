package com.zhengpu.zhengpuandroid.iflytekaction;


import com.zhengpu.zhengpuandroid.iflytekutils.WordsToVoice;

public class OpenQA {

	private String mText;

	public OpenQA(String text){
		mText=text;

	}
	
	public void start(){
		WordsToVoice.startSynthesizer(mText);
	}
}
