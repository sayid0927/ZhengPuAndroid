package com.zhengpu.zhengpuandroid.bean.iflytekbean;



public class SemanticBean {
    /**
     * name : 张三
     */

    private SlotsBean slots;

    public SlotsBean getSlots() {
        return slots;
    }

    public void setSlots(SlotsBean slots) {
        this.slots = slots;
    }


}