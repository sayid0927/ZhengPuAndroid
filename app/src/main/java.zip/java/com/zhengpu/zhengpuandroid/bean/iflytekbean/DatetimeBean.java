package com.zhengpu.zhengpuandroid.bean.iflytekbean;


public class DatetimeBean {
    private String date;
    private String type;
    private String time;
    private String timeOrig;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getTimeOrig() {
        return timeOrig;
    }

    public void setTimeOrig(String timeOrig) {
        this.timeOrig = timeOrig;
    }
}